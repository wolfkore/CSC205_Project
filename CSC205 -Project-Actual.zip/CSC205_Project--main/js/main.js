
inputText.oninput = function () {
  search();
  
}

flexCheck.onclick = function () {
  if (document.getElementById("flexCheck").checked == true) {
    toOpen();
  }
  else if (document.getElementById("flexCheck").checked == false) {
    toNormal();
  }
}

flexCheckCS.onclick = function () {
  if (document.getElementById("flexCheckCS").checked == true) {
    toCS();
  }
  else if (document.getElementById("flexCheckCS").checked == false) {
    toNormal();
  }
}

flexCheckTax.onclick = function () {
  if (document.getElementById("flexCheckTax").checked == true) {
    toTax();
  }
  else if (document.getElementById("flexCheckTax").checked == false) {
    toNormal();
  }
}

let courses = "";

var userInput = document.getElementById("inputText").innerHTML; 
var etarget = ""; 

inputText.addEventListener("input", (e) => etarget = e.target.value); 

window.onload = (event) => {
  let server = new XMLHttpRequest();
  server.open("GET", "https://csc205.cscprof.com/courses", true)
  server.send(); 

  server.onload = function() {
    if (server.status >= 200 && server.status < 300) {
      courses = JSON.parse(server.responseText); 

    }
    document.getElementById("inputText").focus(); 
    //fixNull(courses); 
    // assign a variable to hold the edited array
    let newData = deleteColumns(courses); 
    // get the table id 
    var table = document.getElementById("course-table");
    // assign the information variable
    let information = Object.keys(newData[0]);
    // actual use the function
    makeTableHeader(table, information);
    makeTable(table, newData);
  }
  
}
 //create a function to make the table
	function makeTableHeader(table, information) {
	//actually generate the table header
	let thead = table.createTHead();
  thead.setAttribute("id", "course-head");
  // insert the row 
  let row = thead.insertRow();
  // fill the cells with the courses information
  for (let column of information) {
    let th = document.createElement("th");
    let text = document.createTextNode(column);
    th.appendChild(text);
    row.appendChild(th);
  }
}
// create the rest of the table
function makeTable(table, information) {
	// create the table body

	let tbody = table.createTBody();
  tbody.setAttribute("id", "course-data");

	// fill in all of the cells of the tbody
  for (let element of information) {
    let row = tbody.insertRow();
	//loop through courses and fill in the proper cells
    for (key in element) {
        let cell = row.insertCell();
        
        cell.innerHTML = objFixNull(element);
        
        if (key == "Number") {
          let htmlLink = '<a href="details.html?id=' + element.id + '" class="link-warning text-decoration-none">' + element.Number + '</a>';
          cell.innerHTML = htmlLink;
        } else if (key == "Email") {
          let emailLink = '<a href="mailto:' + element.Email + '"class="link-warning text-decoration-none">' + element.Email + '</a>';
          cell.innerHTML = emailLink;
        } else {
          cell.innerHTML = element[key];
        } 
                  
        } 

        
    }
  }


function deleteColumns(courses) {
	// delete the necessary columns out of the table.
	courses.forEach(function (course) {
		delete course.Line;
		delete course.Section;
		delete course.Openings;
		delete course.Capacity; 
		delete course.Room;
		delete course.Start; 
		delete course.End;
		delete course.Campus; 
    delete course["Start Date"]; // remember this
    delete course["End Date"]; // remember this
		
	}); 
	// return the edited courses array
	return courses; 
}

function objFixNull(blah) {
  if (!blah[key]) {
    blah[key] = '-';
  }
}

function search() {
  let tbody = document.getElementById("course-data");
  tbody.remove();

  let x = courses.filter(oneClass => Object.keys(oneClass)
    .some(key => String(oneClass[key]).toLowerCase().includes(etarget.toLowerCase()))); 
  let table = document.getElementById("course-table");
  
  makeTable(table, x); 
}

function toOpen() {
  let tbody = document.getElementById("course-data");
  tbody.remove();

  let x = courses.filter(oneClass => Object.keys(oneClass)
  .some(key => String(oneClass[key]).includes('Open'))); 
  let table = document.getElementById("course-table");
  
  makeTable(table, x); 
}

function toNormal() {
  let tbody = document.getElementById("course-data");
  tbody.remove();

  let x = courses.filter(oneClass => Object.keys(oneClass)
  .some(key => String(oneClass[key]))); 
  let table = document.getElementById("course-table");
  
  makeTable(table, x); 
}

function toCS() {
  let tbody = document.getElementById("course-data");
  tbody.remove();

  let x = courses.filter(oneClass => Object.keys(oneClass)
  .some(key => String(oneClass[key]).includes('CSC'))); 
  let table = document.getElementById("course-table");
  
  makeTable(table, x); 
}

function toTax() {
  let tbody = document.getElementById("course-data");
  tbody.remove();

  let x = courses.filter(oneClass => Object.keys(oneClass)
  .some(key => String(oneClass[key]).includes('TAXATION'))); 
  let table = document.getElementById("course-table");
  
  makeTable(table, x); 
}