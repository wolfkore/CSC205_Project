let courses = [
    {"Line":81,"Department":"BUS","Number":344,"Section":1,"Title":"MANAGEMENT OF INFORMATION SYSTEMS","Faculty":"Richards, Gordon P.","Openings":2,"Capacity":30,"Status":"Open","Day":"MWF","startTime":"1:25 PM","endTime":"2:20 PM","Campus":" Main Campus","Building":" Science and Engineering","Room":"SE 341 Computer Science Lab","Credits":3,"Start":"8\/30\/2021","End":"12\/17\/2021\r\n"}
    ,{"Line":167,"Department":"CSC","Number":133,"Section":2,"Title":"SURVEY OF COMPUTER SCIENCE","Faculty":"Madeira, Scott","Openings":6,"Capacity":15,"Status":"Open","Day":"H","startTime":"2:00 PM","endTime":"4:50 PM","Campus":" Main Campus","Building":" Science and Engineering","Room":" SE 341 Computer Science Lab","Credits":0,"Start":"8\/30\/2021","End":"12\/17\/2021\r\n"}
    ,{"Line":168,"Department":"CSC","Number":133,"Section":3,"Title":"SURVEY OF COMPUTER SCIENCE","Faculty":"Madeira, Scott","Openings":7,"Capacity":15,"Status":"Open","Day":"T","startTime":"6:30 PM","endTime":"9:20 PM","Campus":" Main Campus","Building":" Science and Engineering","Room":" SE 341 Computer Science Lab","Credits":0,"Start":"8\/30\/2021","End":"12\/17\/2021\r\n"}
    ,{"Line":169,"Department":"CSC","Number":133,"Section":"0A","Title":"SURVEY OF COMPUTER SCIENCE","Faculty":"Richards, Gordon P.","Openings":15,"Capacity":45,"Status":"Open","Day":"TH","startTime":"8:00 AM","endTime":"9:20 AM","Campus":" Main Campus","Building":" Science and Engineering","Room":" SE 110 Chemistry room","Credits":4,"Start":"8\/30\/2021","End":"12\/17\/2021\r\n"}
    ,{"Line":170,"Department":"CSC","Number":190,"Section":1,"Title":"HTML","Faculty":"Madeira, Scott","Openings":4,"Capacity":25,"Status":"Open","Day":"M","startTime":"2:30 PM","endTime":"3:25 PM","Campus":" Main Campus","Building":" Science and Engineering","Room":" SE 312A","Credits":1,"Start":"8\/30\/2021","End":"12\/17\/2021\r\n"}
    ,{"Line":171,"Department":"CSC","Number":205,"Section":1,"Title":"HCI DESIGN & PROGRAMMING","Faculty":"Madeira, Scott","Openings":10,"Capacity":25,"Status":"Open","Day":"MWF","startTime":"11:15 AM","endTime":"12:10 PM","Campus":" Main Campus","Building":" Science and Engineering","Room":" SE 341 Computer Science Lab","Credits":3,"Start":"8\/30\/2021","End":"12\/17\/2021\r\n"}
    ,{"Line":172,"Department":"CSC","Number":344,"Section":1,"Title":"MANAGEMENT INFORMATION SYSTEM","Faculty":"Poteete, Paul W. Steffine, Aaron","Openings":2,"Capacity":90,"Status":"Open","Day":"MWF","startTime":"1:25 PM","endTime":"2:20 PM","Campus":" Main Campus","Building":" Science and Engineering","Room":" SE 341 Computer Science Lab","Credits":3,"Start":"8\/30\/2021","End":"12\/17\/2021\r\n"}
    ,{"Line":173,"Department":"CSC","Number":363,"Section":"E1","Title":"DATABASE SYSTEMS","Faculty":"Hinderliter, Jeffery A","Openings":4,"Capacity":30,"Status":"Open","Day":"T","startTime":"6:30 PM","endTime":"9:20 PM","Campus":" Main Campus","Building":" Science and Engineering","Room":" SE 233 Engineering Lab\/Classroom","Credits":3,"Start":"8\/30\/2021","End":"12\/17\/2021\r\n"}
    ,{"Line":296,"Department":"HUM","Number":103,"Section":"0A","Title":"INVITATION TO THE HUMANTIES","Faculty":"Miller, Eric John","Openings":12,"Capacity":180,"Status":"Open","Day":"W","startTime":"11:15 PM","endTime":"12:10 PM","Campus":" Main Campus","Building":" Old Main","Room":" John White Chapel","Credits":0,"Start":"8\/30\/2021","End":"12\/17\/2021"}
]


const courseTitlejs = document.getElementById("courseTitle"); 


window.onload = (event) => {
    let id = getId();

    let serverUrl = getServerUrl(id);

    fetch(serverUrl).then(response => response.json()).then(data => objFixNull(data)).then(data => display(data));

}

function getId() {
    let url_str = document.URL;
    let url = new URL(url_str);
    return url.searchParams.get('id');

}

function getServerUrl(id) {
    console.log(id)
    return "https://csc205.cscprof.com/courses/" + id;
}

function objFixNull(blah) {
    if (!blah) {
      blah = 'N/A';
    } else {return blah};
}

function fixNull() {
    if (boop == null) {
        boop = 'N/A';
    }
    return boop;
}

function display(details) {
objFixNull(details);

if (details.StartTime == null) {
    details.StartTime = 'N/A'; 
}
if (details.EndTime == null) {
    details.EndTime = 'N/A';
}
if (details.Room == null) {
    details.Room = 'N/A';
}
if (details.Building == null) {
    details.Building = "N/A"; 
}

document.getElementById("courseTitle").innerHTML = details.Title;
document.getElementById("courseCode").innerHTML = details.Number; 
document.getElementById("sectionName").innerHTML = details.Section;
document.getElementById("professor").innerHTML = details.Faculty;
document.getElementById("credits").innerHTML = details.Credits;  
document.getElementById("email").innerHTML = '<a href="mailto:' + details.Email + '" class="link-warning text-decoration-none">' + details.Email + '</a>';

// timeP paragraph
document.getElementById("day").innerHTML = details.Day;
document.getElementById("startTime").innerHTML = details.StartTime;
document.getElementById("endTime").innerHTML = details.EndTime;
document.getElementById("building").innerHTML = details.Building; 
document.getElementById("room").innerHTML = details.Room; 
document.getElementById("campus").innerHTML = details.Campus; 
document.getElementById("line").innerHTML = details.Line;

// creditsP paragraph
document.getElementById("status").innerHTML = details.Status;
document.getElementById("seatsOpen").innerHTML = details.Openings; 
document.getElementById("totalSeats").innerHTML = details.Capacity;
document.getElementById("startDate").innerHTML = details["Start Date"]; 
document.getElementById("endDate").innerHTML = details["End Date"];

}




